﻿<!doctype html>
<html>
<!--Gustavo Cunha Teles-->

<head>
<meta charset="utf-8">
<title>Editora</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
</head>

<body>

    <div>
	<form action="url.php" method="post">
   	
   		<fieldset>
   			<h2>Acervo da Editora</h2><br>
   	
   			<select name="op">
        			<option value="1">Inserir obra</option>
        			<option value="2">Atualizar obra</option>
        			<option value="3">Pesquisar por título</option>
          			<option value="4">Listar todas as obras</option>
    			</select>
    	
	    		<br><br><input type="submit" value="Ok" />
   		</fieldset>
  	</form>
    </div>
   

</body>

</html>